import { createContext } from 'react'

const blogContext = createContext()

export default blogContext